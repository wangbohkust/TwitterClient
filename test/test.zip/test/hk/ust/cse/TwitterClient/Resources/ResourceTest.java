package test.hk.ust.cse.TwitterClient.Resources;


import static org.junit.Assert.*;
import hk.ust.cse.TwitterClient.Resources.*;
import hk.ust.cse.TwitterClient.Views.Basic.ClickableComposite;
//import java.io.IOException;
//import java.io.InputStream;
//import java.net.URL;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.junit.Test;

public class ResourceTest {

	@Test
	public void test() {
//		fail("Not yet implemented");
		Resources r=new Resources();
		assertNotNull(r);
		
		/*Display display=new Display();
		Shell shell=new Shell(display);
		ClickableComposite clickableComposite=new ClickableComposite(shell);
	    Event event21=new Event();
	    event21.widget=clickableComposite;
	    
	    event21.type=SWT.MouseHover;
	    Listener listener2[]=clickableComposite.getListeners(SWT.MouseHover);
	    for (Listener i:listener2)
	    {
			i.handleEvent(event21);
		}
	    
	    event21.type=SWT.MouseExit;
	    Listener listener21[]=clickableComposite.getListeners(SWT.MouseExit);
	    for (Listener i:listener21)
	    {
			i.handleEvent(event21);
		}
	    
	    event21.type=SWT.MouseEnter;
	    Listener listener211[]=clickableComposite.getListeners(SWT.MouseEnter);
	    for (Listener i:listener211)
	    {
			i.handleEvent(event21);
		}
	    
	    shell.dispose();
	    display.dispose();*/
	    
	}

	  


}
