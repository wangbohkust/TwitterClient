package test.hk.ust.cse.TwitterClient;

import junit.framework.TestCase;

import org.junit.Test;

import twitter4j.conf.ConfigurationBuilder;
import hk.ust.cse.TwitterClient.TwitterClient;

public class TwitterClientTest extends TestCase{
	
 @Test(timeout=10000)
 public void testConstructor() throws Throwable {
	 
	 ConfigurationBuilder builder = new ConfigurationBuilder();
	    builder.setDebugEnabled(false);
		
	    builder.setOAuthConsumerKey("jCuspkHm65ZsTHFZvq5usw");
	    		
	    builder.setOAuthConsumerSecret("z0Kw6s1OG27rTtShhS8x9VUyAUlaH7VoLHSr3dy7RMM");
	    		
	    builder.setOAuthAccessToken("1155799626-h5p6jpWaSlbQetb7i0koHtfWbnmBbaDUXXcMgEX");
	    		
	    builder.setOAuthAccessTokenSecret("hClIuYyhKvVm10HiE5TcbsyAypHQt9sIlJkQrwiPtg");
	 TwitterClient tc=new TwitterClient(1000,1000);
	 TwitterClient.main(null);
	 tc.toString();
 }
 public void testMain() throws Throwable{
	
 }
}
